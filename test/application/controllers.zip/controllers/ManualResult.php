<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ManualResult extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this -> load -> model('Person');
        $this -> load -> model('Manual_result_model');
        $this -> is_logged_in();
    }
    function is_logged_in() {
        $is_logged_in = $this -> session -> userdata('is_logged_in');
        $person_cat_id = $this -> session -> userdata('person_cat_id');
        if (!isset($is_logged_in) || $is_logged_in != 1 || $person_cat_id!=1) {
            echo 'you have no permission to use admin area'. '<a href="#!" ng-click="goToFrontPage()">Login</a>';
            die();
        }
    }
    function get_products(){
        $result=$this->sale_model->select_inforce_products()->result_array();
        $report_array['records']=$result;
        echo json_encode($report_array);
    }


    public function angular_view_set_manual_result(){
        ?>
        <style type="text/css">
            #search-results {
                max-height: 200px;
                border: 1px solid #dedede;
                border-radius: 3px;
                box-sizing: border-box;
                overflow-y: auto;
            }
        </style>
        <div class="d-flex col-12" ng-include="'application/views/header.php'"></div>
        <div class="d-flex col-12">
            <div class="col-12">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs nav-justified indigo" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" ng-style="tab==1 && selectedTab" href="#" role="tab" ng-click="setTab(1)">Manual Result</a>
                    </li>
                </ul>
                <!-- Tab panels -->
                <div class="tab-content">
                    <!--Panel 1-->
                    <div ng-show="isSet(1)">
                        <div id="row my-tab-1" class="bg-cpanel">
                            <style type="text/css">
                                .td-input{
                                    width: 35px;
                                    padding: 0px;
                                    margin-left: 0px;
                                    margin-right: 0px;
                                    font-weight: bold;
                                    color: #000080;
                                    border-radius: 50px;
                                }
                                
                                  .report-table tr th,.report-table tr td{
						                border: 1px solid black !important;
						                font-size: 12px;
						                line-height: 1.5;
						            }
                            </style>
						
                            <form name="resultForm" class="form-horizontal">
                                <div class="d-flex justify-content-center mt-1">
                                        <label  class="col-2">Game Name <span class="text-danger">*</span></label>
                                        <div class="col-3">
                                            <select
                                                    class="form-control "
                                                    data-ng-model="manualData.game"
                                                    data-ng-options="x as x.game_name for x in gameList" ng-change="setTime(manualData);setMrp(manualData)">
                                            </select>
                                        </div>
                                </div>

                                <div class="d-flex justify-content-center mt-1">
                                    <label  class="col-2">MRP</label>
                                    <div class="col-3">
                                        <input class="form-control text-right" ng-model="manualData.mrp | number:2  " readonly>
                                    </div>
                                </div>
                                
                                 

                                <div class="d-flex justify-content-center mt-1">
                                    <label  class="col-2">Time <span class="text-danger">*</span></label>
                                    <div class="col-3">
                                        <select
                                                class="form-control "
                                                data-ng-model="manualData.time"
                                                data-ng-options="x as (x.end_time + ' ' + x.meridiem) for x in showTimeList">
                                        </select>
                                        
                                    </div>
                                    
                                    
                                    <div class="2 pull-right" ng-show="true">
                                        <a href="#" ng-show="!showDetails" ng-click="getlastAndSecondLastTotal(manualData.time.draw_master_id);showDetails=!showDetails">
                                            <i class="fa fa-eye fa-2x" aria-hidden="true"></i>
                                        </a>
                                        
                                        <a href="#" ng-click="showDetails=!showDetails" ng-show="showDetails">
                                        
                                          <i class="fa fa-eye-slash fa-2x" aria-hidden="true"></i>

                                        </a>  
                                    </div>
                                                                        
                                </div>
                                <div class="d-flex justify-content-center mt-1">
                                    <label  class="col-2">Result <span class="text-danger">*</span> </label>
                                    <div class="col-3">
                                        <input class="form-control text-right" required numbers-only ng-model="manualData.result" maxlength="2">
                                    </div>
                                </div>

                              

                                <div class="d-flex justify-content-center mt-3">
                                    <div class="col-3">
                                    	
                                    </div>
                                    <div class="col-3">
                                        <input class="btn-secondary" type="button" value="Submit" ng-click="submitManualResult(manualData)" ng-disabled="resultForm.$invalid">
                                    </div>
                                </div>

                                <div class="d-flex justify-content-center mt-2">
                                    <div class="">
                                        <span ng-show="submitStatus" class="text-success h5">Result submitted</span>
                                    </div>
                                </div>

                            </form>
                            
                            
                            <div class="d-flex" ng-show="showDetails">
                            	<div class="col" offset="2">
                            		<table cellpadding="0" cellspacing="0" class="table table-bordered table-hover report-table small text-justify">
                                                    <thead>
                                                    <tr>
                                                        <th class="p-0 text-center">Place</th>
                                                        <th class="p-0  text-center">Zero</th>
                                                        <th class="p-0  text-center">One</th>
                                                        <th class="p-0  text-center">Two</th>
                                                        <th class="p-0 text-center">Three</th>
                                                        <th class="p-0  text-center">Four</th>
                                                        <th class="p-0  text-center">Five</th>
                                                        <th class="p-0 text-center ">Six</th>
                                                        <th class="p-0 text-center ">Seven</th>
                                                        <th class="p-0 text-center ">Eight</th>
                                                        <th class="p-0 text-center ">Nine</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>

                                                    <tr ng-repeat="x in secondLastTotal" >
                                                        <td class="p-0 text-center">
                                                           {{x.box}}
                                                        </td>
                                                        <td class="p-0 text-center"> {{x.zero}}</td>
                                                        <td class="p-0 text-center">{{x.one}}</td>
                                                        <td class="p-0  text-center">{{x.two}}</td>
                                                        <td class="p-0  text-center">{{x.three}}</td>
                                                        <td class="p-0  text-center">{{x.four}}</td>
                                                        <td class="p-0 text-center">{{x.five}}</td>
                                                        <td class="p-0 text-center">{{x.six}}</td>
                                                        <td class="p-0 text-center">{{x.seven}}</td>
                                                        <td class="p-0 text-center">{{x.eight}}</td>
                                                        <td class="p-0 text-center">{{x.nine}}</td>
                                                        
                                                    </tr>


                                                    </tbody>


                                                </table>
                            		<div ng-show="alertMsg" class="text-center">No records</div>
                            		
                            		
                            	</div>
                            </div>
                            
                            
                            
                            
                            

<!--                            <div class="d-flex">-->
<!--                                <div class="col-4">-->
                                 <!-- <pre>manualData = {{manualData | json}}</pre>-->
<!--                                </div>-->
<!--                                <div class="col-4"><pre>cardPayOut ={{cardPayOut| json}}</pre></div>-->
<!--                                <div class="col-4"><pre>showTimeList={{showTimeList | json}}</pre></div>-->
<!--                           </div>-->
                        </div> <!--//End of my tab1//-->
                    </div>

                </div>
            </div>
        </div>

        <?php
    }

    public function get_all_series(){
        $result=$this->Manual_result_model->select_series()->result_array();
        $report_array['records']=$result;
        echo json_encode($report_array);
    }
     public function get_all_digit_draw_time(){
        $result=$this->Manual_result_model->select_ten_digit_draw_time()->result_array();
        $report_array['records']=$result;
        echo json_encode($report_array);
    }

    public function get_all_card_draw_time(){
        $result=$this->Manual_result_model->select_card_draw_time()->result_array();
        $report_array['records']=$result;
        echo json_encode($report_array);
    }

     public function get_game2_payout(){
        $result=$this->Payout_settings_model->select_game2_payout()->result_array();
        $report_array['records']=$result;
        echo json_encode($report_array);
    }


    function get_digit_manual_result(){
        $post_data =json_decode(file_get_contents("php://input"), true);
        $result=$this->Manual_result_model->insert_digit_game_manual_result((object)$post_data['master']);
        $report_array['records']=$result;
        echo json_encode($report_array,JSON_NUMERIC_CHECK);

    }

    function get_twelve_card_manual_result(){
        $post_data =json_decode(file_get_contents("php://input"), true);
        $result=$this->Manual_result_model->insert_twelve_card_game_manual_result((object)$post_data['master']);
        $report_array['records']=$result;
        echo json_encode($report_array,JSON_NUMERIC_CHECK);

    }


    function update_stockist_by_stockist_id(){
        $post_data =json_decode(file_get_contents("php://input"), true);
        $result=$this->Stockist_model->update_stockist_details((object)$post_data['stockist']);
        $report_array['records']=$result;
        echo json_encode($report_array);
    }
    
    
     public function get_place_values(){
     	$post_data =json_decode(file_get_contents("php://input"), true);
        $result=$this->Manual_result_model->get_second_and_last_total($post_data['draw_id'])->result_array();
        $report_array['records']=$result;
        echo json_encode($report_array);
    }

    public function get_current_user_id(){
        $result=$this->Stockist_model->select_next_user_id_for_stockist();
        echo $result;
    }


}
?>