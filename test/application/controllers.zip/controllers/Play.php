<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Play extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this -> load -> model('Person');
        $this -> load -> model('Game_model');
        
        //$this -> is_logged_in();
    }
    /*function is_logged_in() {
        $is_logged_in = $this -> session -> userdata('is_logged_in');
        $person_cat_id = $this -> session -> userdata('person_cat_id');
        if (!isset($is_logged_in) || $is_logged_in != '1' || $person_cat_id!=3) {
            echo 'you have no permission to use this area'. '<a href="#!" ng-click="goToFrontPage()">Login</a>';
            die();
        }
    }*/
    
    function get_sessiondata(){
        echo json_encode($this->session->userdata(),JSON_NUMERIC_CHECK);
    }
    

    function get_active_terminal_balance(){
        $terminal_id=$this-> session -> userdata('person_id');
        $result=$this->Game_model->select_terminal_balance($terminal_id);
        $report_array['records']=$result;
        echo json_encode($report_array,JSON_NUMERIC_CHECK);
    }




    public function angular_view_play(){
        ?>
        <style>
            .report-table tr th,.report-table tr td{
                /*border: 1px solid black !important;*/
               /* font-size: 12px;*/
                line-height: 0px;
                white-space:nowrap;
                border-style:hidden;
            }
            table td{
                width: 1%;
            }

            .joditextBoxClass {
                width: 85px;
                height: 20px;
                text-align: center;
                font-weight: bold;
                font-family: Verdana, Arial, Helvetica, sans-serif;
            }
            .textBoxClass {
                width: 45px;
                height: 20px;
                text-align: center;
                font-weight: bold;
                font-family: Verdana, Arial, Helvetica, sans-serif;
            }
            

            .footer {
                position: fixed;
                left: 0;
                bottom: 0;
                width: 100%;
                background-color: red;
                color: white;
                text-align: center;
            }
            .card{
                /*height: 100vh;*/
            }
            .card-footer{
              /* height: 15vh;*/
                font-size: 9px;
                line-height: 18px;
            }
            .submit a {
                color: white;
                background-color: #AA2E85;
                padding: 5px 11px;
                border-style: 2px solid
            }
           /* .result-list{
				 height: 150px;       /* Just for the demo          */
    			overflow-y: auto;    /* Trigger vertical scroll    */
			}*/
			
			.table-style{
				border: 1px solid black !important;
                font-size: 12px;
			}
			.result-panel{
                height: 300px;
                overflow-y:scroll;
			}
		
            
        </style>
        <div class="container" id="pagewrap">       
        
        

            <div class="card"  id="content">
                <div class="card-header pt-0 pb-0">
                    
                            <!-- The modal -->
	                <div class="modal fade in" id="flipFlop" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
	                    <div class="modal-dialog" role="document">
	                        <div class="modal-content">
	                            <div class="modal-header p-0">
	                                <h6 class="modal-title" id="modalLabel" style="font-size:4vw;">
	                                    <!--<i class="fa fa-user"></i> User Login-->
	                                    <img class="img-responsive pl-2" src="img/commander-logo.png"> Commander
	                                </h6>
	                               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	                                    <span aria-hidden="true">&times;</span>
	                                </button>
	                            </div>
	                            <div class="modal-body">
	                            	<div class="container">
	                            	
	                            		<!--Login form-->
								      <form name="login_form" ng-show="loginModal">
										    <div class="form-group">
										      <label for="email">Card No:</label>
										      <input type="text" class="form-control" ng-model="loginData.user_id"  placeholder="Enter CardNo" required>
										    </div>
										    <div class="form-group">
										      <label for="pwd">Pin No:</label>
										      <input type="password" class="form-control" ng-model="loginData.user_password"  placeholder="Enter password" required>
										    </div>
										    <button type="submit" ng-click="login(loginData)"  ng-disabled="login_form.$invalid" class="btn btn-primary">Login</button>
									</form>
										<!--End of Login form-->
										
										<!-- Show result -->
										<div  ng-show="!loginModal" class="result-panel">
											<table st-safe-src="resultData" st-table="displayCollection"  style="width: 100%" cellpadding="0" cellspacing="0" class="table table-bordered table-hover report-table small text-justify" ng-show="!loginModal">
										 	<tbody>
										 		<tr height="33" align="center" style="border-style: hidden">
										 		<td class="text-left">
										 			<input type="date" class="form-control" ng-model="result_date">
										 		</td>
			                                       <td class="text-left"><a href="#" class="btn btn-info rounded-circle" ng-click="getResultListByDate(result_date)" role="button">Show</a></td>
			                                   </tr>
			                                   <tr height="33" align="center">
			                                       <td class="text-left font-weight-bold" width="20%">Time</td>
			                                       <td class="text-left font-weight-bold" width="20%">Game Name</td>
			                                       <td class="text-left font-weight-bold" width="20%">Result</td>
			                                   </tr>
			                                   
			                                   <tr height="33" align="center" ng-repeat="x in displayCollection">
			                                       <td class="text-left" width="20%">{{x.end_time +' ' +x.meridiem}}</td>
			                                       <td class="text-left" width="20%">{{x.draw_name}}</td>
			                                       <td class="text-left" width="20%">{{x.result_row + ''+ x.result_column}}</td>
			                                   </tr>
			                                  
										 	</tbody>
										 	
										 	
										 <!--	<tfoot>
												<tr>
													<td colspan="5" class="text-center">
														<div st-pagination="" st-items-by-page="6" st-displayed-pages="7"></div>
													</td>
												</tr>
											</tfoot>-->
										 	
                              			 </table>
										</div>
										<!--End of Show result -->
										
										
								</div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
		<!--    end of modal-->
  							<table class="table-responsive">
                                   <tr height="33" align="center">
                                       <td ng-repeat="x in gameNameList">
	                                       	<span class="d-inline-block" tabindex="0" data-toggle="tooltip" title="{{ x.draw_name}}">
	  											<button class="btn btn-secondary" style="pointer-events: none;" type="button" disabled>{{(x.end_time | limitTo: 5) + ' '+(x.meridiem)}}</button>
											</span>
	                                       
	                                       	<div class="d-flex bg-maroon flex-column text-white">
									            <div class="display-4 text-center">{{resultValue[$index]}}</div>
									        </div>
                                       </td>

                                   </tr>
                               </table>
		
		

                </div>
                                
                <div class="card-body p-0">
                        <div class="d-flex flex-column">
                            <div class=" submit bg-info text-white">
                             	<a href="#" ng-show="isLogIn" ng-click="loginModal=true" type="button" class="rounded-circle text-white" data-toggle="modal" data-target="#flipFlop" >
			                        Login <i class="fas fa-sign-in-alt"></i>
			                    </a>
			                    <a href="#" ng-show="isLogOut" ng-click="logoutCpanel()" type="button" class="rounded-circle text-white">
			                        Logout <i class="fas fa-sign-in-alt"></i>
			                    </a>
			                    
			                    
                                <span class="text-left pl-5" >Terminal id:<b>{{huiSessionData.user_id ? huiSessionData.user_id : 'XXXX'}}</b>
                                
                                &nbsp;</span>
                                <span class="text-left">Agent:<b>{{huiSessionData.person_name ? huiSessionData.person_name : 'XXXX'}}</b>&nbsp;</span>
                                <span class="text-left">Balance:{{activeTerminalDetails.current_balance | number:2}}&nbsp;</span>
                                <span class="text-left">Current time:{{show_time}}&nbsp;</span>
                                <input type="button" ng-show="false"  class="rounded border border-secondary" value="JODI" ng-click="singleGame=false;jodiGame=true;playInput=defaultPlayInput">
                                <input type="button" ng-show="false" class="rounded border border-secondary" value="SINGLE" ng-click="jodiGame=false;singleGame=true;playInput=defaultPlayInput">
                               <!-- <input type="button" class="rounded-circle text-white pull-right bg-primary" data-toggle="modal" data-target="#flipFlop" value="RESULT" ng-click="loginModal=false">-->
                               <a href="#" ng-click="getActiveTerminalBalance()"><i class="fas fa-sync-alt"></i></a>
                               
                                <a href="#!reportterm" ng-class="{disabled:isLogIn}" target="_blank" class="btn rounded-circle text-white pull-right" role="button">Report</a>
                                <a href="" class="btn rounded-circle text-white pull-right" data-toggle="modal" data-target="#flipFlop" role="button" ng-click="loginModal=false">Result</a>
                            </div>
                            <div  style="background-color: #e16e3e">
                               <table class="table-responsive">
                                   <tr height="33" align="center">
                                       <td class="text-left pl-2">
                                       		<img class="img-responsive" src="img/commander-logo.png">
                                       		<span class="text-center"><a class="text-dark" style="text-shadow: 2px 2px #00aeff;font-size:3vw">{{drawTimeList[0].draw_name}}</a>&nbsp;</span>
                                       </td>
                                       <td colspan="2" class="text-right p-0">
                                           <h2 class="glow" style="font-size:4vw;font-family: Jazz LET, fantasy">
                                           <span ng-show="remainingTime>=0">{{remainingTime | formatDuration}}</span></h2>

                                       </td>
                                   </tr>
                               </table>
                                <table class="table-bordered table-responsive report-table" >


                                    <tr  height="33" align="center" bgcolor="#254a36" ng-repeat="r in getRow(row) track by $index" ng-init="rowIndex = $index">

                                        
                                         <td ng-repeat="c in getCol(coloumn) track by $index" ng-init="columnIndex = $index">
                                         <div class="pb-2 pt-2 text-white font-weight-bold">
                                         {{columnIndex==10 ? 'E'+ rowIndex : columnIndex==11? rowIndex + '0 - ' + rowIndex + '9' : rowIndex+''+columnIndex}}
                                         </div>
                                                    <input tabindex="($index+1)"
                                                            type="text" numbers-only ng-model="playInput[rowIndex][$index]" ng-change="" ng-keyup="verticallyHorizontallyPushValue($index,rowIndex)"
                                                            ng-style="$index==10 && verticalBoxCss || $index==11 && horizontalBoxCss"
                                                            maxlength="3" class="joditextBoxClass text-right">
                                        </td>
                                        
                                    </tr>




                                    <tr class="bg-success hide_all" height="33" align="center">
                                        <td colspan="5" class="text-left text-white font-weight-bold">
                                        <!-- <span class="text-left" ng-mouseover="hoverIn()" data-toggle="modal" data-target="#modal1" id="b1">Draw time:<a class="text-dark" style="text-shadow: 2px 2px red;font-size:5vh">{{drawTimeList[0].end_time  | limitTo: 5}}{{drawTimeList[0].meridiem}}</a>&nbsp;</span> -->
                                          <span class="text-left" ng-mouseover="hoverIn()" >Draw time:<a class="text-dark" style="text-shadow: 2px 2px red;font-size:5vh">{{drawTimeList[0].end_time  | limitTo: 5}}{{drawTimeList[0].meridiem}}</a>&nbsp;</span>
                                          <span class="text-left">{{gameStartingDate}}&nbsp;</span>
                                          <span class="text-left" style="text-shadow: 0 0 3px #FF0000, 0 0 5px #0000FF">&nbsp;MRP:{{seriesList[0].mrp | number:2}} </span>
                                          <span class="text-left" style="text-shadow: 0 0 3px #FF0000, 0 0 5px #0000FF">&nbsp; WIN:{{seriesList[0].winning_price}}</span>
                                         <!-- <span class="text-left" ng-show="jodiGame">Draw time:{{drawTimeList[0].end_time + ' '+ drawTimeList[0].meridiem}} 23/02/19&nbsp;MRP:{{seriesList[0].mrp}} WIN:{{seriesList[0].winning_price}}</span>-->
                                        </td>
                                        <td colspan="9">
                                            <div class="d-flex pb-1">
                                             	<div class="col-2 mt-1">
                                                     <button class="btn rounded-circle btn-warning" ng-disabled="disable2d"  ng-click="submitGameValues(playInput)">BUY</button>
                                                </div>

                                                <div class="col-3">
                                                    <div class="text-center pb-2 pt-2 text-white ">Tickets</div><input type="text" ng-model="totalBoxSum" class="joditextBoxClass" readonly>
                                                </div>
                                                <div class="col-3">
                                                    <div class="text-center pb-2 pt-2 text-white ">Total</div><input type="text" ng-model="totalTicketBuy" class="joditextBoxClass" readonly>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                </table>
                                <table class="table-responsive">
                                	<tr  height="33" align="center" style="background-color: #005e66">
                                      <td class="text-white" colspan="10">
                                      <marquee>{{scrollingMsg.message}}</marquee>
                                      </td>
                                    </tr>
                                </table>

                            </div>


                        </div>

                </div>


                
                
                
				<div class="card-footer bg-dark text-white p-0 m-0 text-justify">

                    <div class="row">
                    <div class="col-md-2 col-lg-2 col-sm-2 col-xs-2"></div>
                        <div class="col-md-8 col-sm-8 col-lg-8 col-xs-8">
                            It's a amusement Game. So  use of  this website as lottery or any other illegal means is strictly prohibited.
Viewing this website is on your own risk. All the information shown here is sponsored and we warn you that Amusement  Numbers are only for fun.
We are not responsible for any issues or scam. We respect all country, state rules/laws. If you not agree with our site disclaimer. Please quit our site right now.
 @Copyright2019 All rights reserved to Nirmal Group software development co..
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-2 col-lg-2"></div>
                    </div>
				</div>
            </div>

            
			<div class="d-flex" ng-show="false">
				<div class="col-3"></div>
				<div class="col-3">
                    showAnimation{{showAnimation}}<br>
                    gif1	{{gif1}}<br>
                    gif2	{{gif2}}<br>
				</div>
			</div>



        <!-- Modal 1 -->
        <div class="modal fade" ng-show="showAnimation" id="modal1" tabindex="-1" role="dialog" aria-labelledby="modal1Label" aria-hidden="true">
            <div class="modal-dialog modal-sm modal-left">
                <div class="modal-content">
                    <div class="" style="padding:0;">
                    <img class="img-responsive" vertical-align:middle src="img/animation.gif" ng-show="gif1">
                    <img class="img-responsive" vertical-align:middle src="img/animation2.gif" ng-show="!gif1">
                    <div class="centered" ng-show="!gif1">
                   t <span class="count">100</span>
                    </div>  
                    
                    </div>
                </div>
            </div>
        </div>

        <!-- End of Modal 1 -->
        <style>
            .centered {
                position: absolute;
                top: 50%;
                left: 80%;
                transform: translate(-50%, -50%);
                color: #f71e78;
            }
            .count
            {
            color:white;
            font-size:40px;
            }
        </style>
        
          




<!--        PRINT PAGE-->

        <div class="container" id="receipt-div" ng-show="false" ng-repeat="x in barcodeList">
            <div ng-repeat="x in barcodeList">
                <h4>{{x.bcd}}</h4>
                <div class="d-flex col-12 mt-1 pl-0">
                    <label  class="col-2">Barcode</label>
                    <div class="col-6">
                        <span ng-bind="x.bcd">: </span>
                    </div>
                </div>
                <div class="d-flex col-12 mt-1 pl-0">
                    <label  class="col-3">Commander 2DIGIT {{x.series_name}} - {{seriesList[0].mrp}}</label>
                </div>

                <div class="d-flex col-12 mt-1 pl-0">
                    <label  class="col-1">Date:</label><span ng-bind="purchase_date"></span>

                    <label  class="col-1">Dr.Time:</label> <span ng-bind="ongoing_draw" class="col-1"></span>
                </div>
                <hr style="border-top: dotted 1px;" />

                <div class="d-flex flex-wrap align-content-start">
                    <div class="p-2" ng-repeat="i in allGameValue track by $index">
                        {{i + ','}}&nbsp;

                    </div>
                </div>


                <hr style="border-top: dotted 1px;" />
                <div class="d-flex col-12">
                    <label  class="col-1">MRP</label><span>: {{seriesList[0].mrp}}</span>
                    <label  class="col-1">Qty:</label> <span ng-bind="totalticket_qty| number:2"></span>
                    <label  class="col-2">{{purchase_time}}</label>
                </div>
                <div class="d-flex col-12">
                    <label  class="col-1">Rs:</label><span ng-bind="totalticket_purchase|number: 2"></span>
                </div>
                <div class="d-flex col-12">
                    <label  class="col-2">Terminal Id</label><span>: <?php echo ($this->session->userdata('user_id'));?></span>

                </div>
                <div class="d-flex col-12">
                    <angular-barcode ng-model="x.bcd" bc-options="barcodeOilBill" bc-class="barcode" bc-type="img"></angular-barcode>
                </div>

            </div>


        </div>




<!--        END-->



        <?php
    }

    

    public function insert_game_values(){
        $post_data =json_decode(file_get_contents("php://input"), true);
        $result=$this->Game_model->insert_game_values((object)$post_data['playDetails'],$post_data['checkList'],$post_data['drawId'],$post_data['purchasedTicket']);
        $report_array['records']=$result;
        echo json_encode($report_array,JSON_NUMERIC_CHECK);
    }

    public function get_all_play_series(){
        $result=$this->Game_model->select_play_series()->result_array();
        $report_array['records']=$result;
        echo json_encode($report_array,JSON_NUMERIC_CHECK);
    }

    public function get_all_draw_time(){
        $result=$this->Game_model->select_from_draw_master()->result_array();
        $report_array['records']=$result;
        echo json_encode($report_array,JSON_NUMERIC_CHECK);
    }
     public function get_all_draw_name_list(){
        $result=$this->Game_model->select_draw_name_list()->result_array();
        $report_array['records']=$result;
        echo json_encode($report_array,JSON_NUMERIC_CHECK);
    }
    

    public function get_game_activation_details(){
        $result=$this->Game_model->select_game_activation()->result_array();
        $report_array['records']=$result;
        echo json_encode($report_array,JSON_NUMERIC_CHECK);
    }

    public function get_draw_result(){
        $post_data =json_decode(file_get_contents("php://input"), true);

        $result=$this->Game_model->select_game_result_after_each_draw($post_data['drawId']);
        //print_r($result);
//        $report_array['records']=$result->records;
        echo json_encode($result,JSON_NUMERIC_CHECK);
    }


    public function get_previous_result(){
        $result=$this->Game_model->select_previous_game_result()->result_array();
//        $report_array['records']=$result->records;
        echo json_encode($result,JSON_NUMERIC_CHECK);
    }

    public function get_result_sheet_today(){
        $post_data =json_decode(file_get_contents("php://input"), true);
        $result=$this->Game_model->select_today_result_sheet()->result_array();
        echo json_encode($result,JSON_NUMERIC_CHECK);
    }

    public function get_result_by_date(){
        $post_data =json_decode(file_get_contents("php://input"), true);
        $result=$this->Game_model->select_result_sheet_by_date($post_data['result_date'])->result_array();
        echo json_encode($result,JSON_NUMERIC_CHECK);
    }


    
    
    function logout_cpanel(){
    	$user_id=$this->session->userdata('user_id');
    	
    	$result=$this->Game_model->logout_current_session($user_id);
        $newdata = array(
            'person_id'  => '',
            'person_name'     => '',
            'user_id'=> 0,
            'person_cat_id'     => 0,
            'is_logged_in' => 0,
            'is_currently_loggedin' => 0,
        );
        $this->session->set_userdata($newdata);

        echo json_encode($newdata,JSON_NUMERIC_CHECK);
    }
    
    
    public function get_timestamp(){
    	$date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
		echo $date->format('h:i:sA');    
            
    }
    
    
    public function get_message(){
        $result=$this->Game_model->select_message()->result_array();
         $report_array['records']=$result;
        echo json_encode($report_array,JSON_NUMERIC_CHECK);
    }
}
?>
