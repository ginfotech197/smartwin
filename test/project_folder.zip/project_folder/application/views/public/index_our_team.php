<div id="our-team">
    <div class="container">
        <div class="text-center">
            <h3>Our Team</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit Lorem ipsum dolor sit<br>amet consectetur adipisicing elit</p>
        </div>
        <div class="row">
            <div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                <div class="text-center">
                    <img src="img/team/1.png" alt="">
                    <h2>John Doe</h2>
                    <h4>Founder & CEO</h4>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit Fusce fermen tum neque a rutrum varius</p>
                </div>
            </div>
            <div class="col-md-4 wow bounceInDown" data-wow-offset="0" data-wow-delay="0.3s">
                <div class="text-center">
                    <img src="img/team/2.png" alt="">
                    <h2>John Doe</h2>
                    <h4>Creative Director</h4>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit Fusce fermen tum neque a rutrum varius</p>
                </div>
            </div>
            <div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                <div class="text-center">
                    <img src="img/team/3.png" alt="">
                    <h2>John Smith</h2>
                    <h4>Creative Director</h4>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit Fusce fermen tum neque a rutrum varius</p>
                </div>
            </div>
        </div>
    </div>
    <div class="team">
        <div class="container">
            <div class="row">
                <div class="col-md-3 wow fadeInRight" data-wow-offset="0" data-wow-delay="0.3s">
                    <div class="text-center">
                        <img src="img/team/team1.jpg" class="img-responsive" alt="">
                        <h2>John Doe</h2>
                        <h4>Founder & CEO</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit Fusce fermen tum neque a rutrum varius</p>
                    </div>
                </div>
                <div class="col-md-3 wow fadeInRight" data-wow-offset="0" data-wow-delay="0.3s">
                    <div class="text-center">
                        <img src="img/team/team2.jpg" class="img-responsive" alt="">
                        <h2>John Doe</h2>
                        <h4>Creative Director</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit Fusce fermen tum neque a rutrum varius</p>
                    </div>
                </div>
                <div class="col-md-3 wow fadeInLeft" data-wow-offset="0" data-wow-delay="0.3s">
                    <div class="text-center">
                        <img src="img/team/team3.jpg" class="img-responsive" alt="">
                        <h2>John Smith</h2>
                        <h4>Creative Director</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit Fusce fermen tum neque a rutrum varius</p>
                    </div>
                </div>
                <div class="col-md-3 wow fadeInLeft" data-wow-offset="0" data-wow-delay="0.3s">
                    <div class="text-center">
                        <img src="img/team/team4.jpg" class="img-responsive" alt="">
                        <h2>John Smith</h2>
                        <h4>Creative Director</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit Fusce fermen tum neque a rutrum varius</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!--/#our-team-->