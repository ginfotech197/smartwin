<div class="parallax-window">
    <div class="col-md-6 col-md-offset-3">
        <div class="text-center">
            <div class="wow bounceIn" data-wow-offset="0" data-wow-delay="0.2s">
                <h2>Parallax Landing Page</h2>
            </div>
            <div class="wow bounceIn" data-wow-offset="0" data-wow-delay="0.6s">
                <p>In a elit in lorem congue varius Sed nec arcu<br>
                    ullamcorp-er tellus ut dignissim nisi risus non tortor.
                </p>
            </div>
        </div>
    </div>
    <div class="sub-parallax">
        <div class="text-center">
            <div class="col-md-12">
                <div class="wow bounceIn" data-wow-offset="0" data-wow-delay="0.9s">
                    <form class="form-inline">
                        <div class="form-group">
                            <button type="purchase" name="purchase" class="btn btn-primary btn-lg" required="required">Purchase</button>
                        </div>
                        <div class="form-group">
                            <button type="subscribe" name="subscribe" class="btn btn-primary btn-lg" required="required">Subscribe Now</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><!--/#parallax-window-->