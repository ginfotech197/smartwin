    <style type="text/css">
       
        .main-view{
            padding:30px;
            width:100vw;
            height:100vh;
            overflow-y:scroll;
        }
        .inner-border::-webkit-scrollbar { 
                display: none; 
            } 
    </style>
    <div ng-view class="main-view inner-border"></div>
