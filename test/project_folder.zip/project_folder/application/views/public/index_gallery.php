<div id="gallery">
    <div class="container">
        <div class="text-center">
            <h3>Gallery</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit Lorem ipsum dolor sit<br>amet consectetur adipisicing elit</p>
        </div>
        <div class="row">
            <figure class="effect-chico">
                <div class="col-md-3 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                    <a href="img/work/1.jpg" class="flipLightBox">
                        <img src="img/work/1.jpg" class="img-responsive" alt="">
                    </a>
                </div>
            </figure>
            <figure class="effect-chico">
                <div class="col-md-3 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                    <a href="img/work/2.jpg" class="flipLightBox">
                        <img src="img/work/2.jpg" class="img-responsive" alt="">
                    </a>
                </div>
            </figure>
            <figure class="effect-chico">
                <div class="col-md-3 wow fadeInDown" data-wow-offset="0" data-wow-delay="0.3s">
                    <a href="img/work/3.jpg" class="flipLightBox">
                        <img src="img/work/3.jpg" class="img-responsive" alt="">
                    </a>
                </div>
            </figure>
            <figure class="effect-chico">
                <div class="col-md-3 wow fadeInDown" data-wow-offset="0" data-wow-delay="0.3s">
                    <a href="img/work/4.jpg" class="flipLightBox">
                        <img src="img/work/4.jpg" class="img-responsive" alt="">
                    </a>
                </div>
            </figure>
        </div>
    </div>
    <div class="gallery">
        <div class="container">
            <div class="row">
                <figure class="effect-chico">
                    <div class="col-md-3 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                        <a href="img/work/5.jpg" class="flipLightBox">
                            <img src="img/work/5.jpg" class="img-responsive" alt="">
                        </a>
                    </div>
                </figure>
                <figure class="effect-chico">
                    <div class="col-md-3 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                        <a href="img/work/6.jpg" class="flipLightBox">
                            <img src="img/work/6.jpg" class="img-responsive" alt="">
                        </a>
                    </div>
                </figure>
                <figure class="effect-chico">
                    <div class="col-md-3 wow fadeInDown" data-wow-offset="0" data-wow-delay="0.3s">
                        <a href="img/work/7.jpg" class="flipLightBox">
                            <img src="img/work/7.jpg" class="img-responsive" alt="">
                        </a>
                    </div>
                </figure>
                <figure class="effect-chico">
                    <div class="col-md-3 wow fadeInDown" data-wow-offset="0" data-wow-delay="0.3s">
                        <a href="img/work/8.jpg" class="flipLightBox">
                            <img src="img/work/8.jpg" class="img-responsive" alt="">
                        </a>
                    </div>
                </figure>
            </div>
        </div>
    </div>
</div><!--/#gallery-->